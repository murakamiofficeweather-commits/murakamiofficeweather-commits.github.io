﻿# JMA Wind Icons for Google Sheets

Static PNG wind icons for the Google Sheets =IMAGE() function.

## Publish with GitHub Pages

1. Create a new public GitHub repository.
2. Upload the contents of this github-pages-wind-icons folder to the repository root.
3. Open Settings > Pages.
4. Set Source to Deploy from a branch.
5. Select branch main and folder / (root).
6. Wait a few minutes, then open https://USER.github.io/REPOSITORY/.

Image URLs look like this:

`	ext
https://USER.github.io/REPOSITORY/wind-icons/wind_s2_n.png
`

sset-url-template.csv contains the URL mapping template.
Replace YOUR_GITHUB_USERNAME and YOUR_REPOSITORY_NAME with real values.
